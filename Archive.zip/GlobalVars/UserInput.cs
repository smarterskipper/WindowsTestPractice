using System;

namespace GlobalVars
{
    public class UserInput
    {
        public static string ReadInputLine()
        {
            var userVar = Console.ReadLine();
            return userVar;
        }
    }
}